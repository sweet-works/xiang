$(".head").load("data/data.html .box_head");
$(".nav").load("data/data.html .box_nav");
$(".footer").load("data/data.html .box_footer");
$(".footer_foot").load("data/data.html .box_footer_foot");